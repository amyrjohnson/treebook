class Status < ActiveRecord::Base
  attr_accessible :content, :name
end
